package com.crypcomapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.JsonReader;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Pie;
import com.anychart.charts.Waterfall;

import com.crypcomapp.R;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class BitcoinChartActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        new BitcoinCharts().execute(); //hacemos execute


    }

    private class BitcoinCharts extends AsyncTask<View, Void, ArrayList<DataEntry>> {

        @Override
        protected ArrayList<DataEntry> doInBackground(View... urls) {
            ArrayList<DataEntry> temp;
            //print the call in the console
            System.out.println("https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency=USD&days=60&interval=daily");

            // make Call to the url

            temp = makeCall("https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency=USD&days=60&interval=daily");


            return temp;
        }

        @Override
        protected void onPreExecute() {
            // we can start a progress bar here
            //anyChartView.setProgressBar(findViewById(R.id.ProgressBar));

        }

        @Override
        protected void onPostExecute(ArrayList<DataEntry> prices) {


            AnyChartView anyChartView = findViewById(R.id.any_chart_view);

            Waterfall waterfall = AnyChart.waterfall();

            waterfall.title("ACME corp. Revenue Flow 2017");

            waterfall.yScale().minimum(0d);

            waterfall.yAxis(0).labels().format("${%Value}{scale:(1000000)(1)|(mln)}");
            waterfall.labels().enabled(true);
            waterfall.labels().format(
                    "function() {\n" +
                            "      if (this['isTotal']) {\n" +
                            "        return anychart.format.number(this.absolute, {\n" +
                            "          scale: true\n" +
                            "        })\n" +
                            "      }\n" +
                            "\n" +
                            "      return anychart.format.number(this.value, {\n" +
                            "        scale: true\n" +
                            "      })\n" +
                            "    }");

            List<DataEntry> data = new ArrayList<>();
            data.add(new ValueDataEntry("Start", 23000000));
            data.add(new ValueDataEntry("Jan", 2200000));
            data.add(new ValueDataEntry("Feb", -4600000));
            data.add(new ValueDataEntry("Mar", -9100000));
            data.add(new ValueDataEntry("Apr", 3700000));
            data.add(new ValueDataEntry("May", -2100000));
            data.add(new ValueDataEntry("Jun", 5300000));
            data.add(new ValueDataEntry("Jul", 3100000));
            data.add(new ValueDataEntry("Aug", -1500000));
            data.add(new ValueDataEntry("Sep", 4200000));
            data.add(new ValueDataEntry("Oct", 5300000));
            data.add(new ValueDataEntry("Nov", -1500000));
            data.add(new ValueDataEntry("Dec", 5100000));
            DataEntry end = new DataEntry();
            end.setValue("x", "End");
            end.setValue("isTotal", true);
            data.add(end);

            waterfall.data(data);
        }
    }

    public static ArrayList<DataEntry> makeCall(String stringURL) {
        System.out.println("MAKECALL METHOD");
        URL url = null;
        BufferedInputStream is = null;
        JsonReader reader;
        ArrayList <DataEntry> prices = new ArrayList();
        int contador=1;
        try {
            url = new URL(stringURL);
        } catch (Exception ex) {
            System.out.println("Malformed URL");
        }

        try {
            if (url != null) {
                System.out.println("url not NULL");
                HttpsURLConnection urlConnection = (HttpsURLConnection) url.openConnection();
                is = new BufferedInputStream(urlConnection.getInputStream());
                System.out.println("new BufferInputStream");
            }
        } catch (IOException ioe) {
            System.out.println("IOException");
        }

        if (is != null) {
            try { //apartir de aqui cogemos de simulador java

                System.out.println("Iniciando JSon");
                reader = new JsonReader(new InputStreamReader(is, "UTF-8"));
                reader.beginObject();

                reader.nextName();       //leemos prices
                System.out.println("Leemos prices");
                reader.beginArray();            //abrimos array general
                System.out.println("abrimos array general");

                while(contador<=61){

                    reader.beginArray();            //abrimos array de datos
                    System.out.println("abrimos array de datos");
                    reader.nextDouble();            //leemos dato que no queremos
                    System.out.println("leemos dato que no queremos");
                    //prices.add((double)Math.round(reader.nextDouble() * 1000d) / 1000d);    //cogemos precio

                    if(contador==1 || contador%7==0 || contador ==61){

                        prices.add(new ValueDataEntry(contador+"d",
                                (double)Math.round(reader.nextDouble() * 1000d) / 1000d));
                        System.out.println("añadimos");

                    }else{
                        prices.add(new ValueDataEntry("",
                                (double)Math.round(reader.nextDouble() * 1000d) / 1000d));
                        System.out.println("añadimos");
                    }
                    //System.out.println("Posición: " + prices.size() + " Precio: " + prices.get(prices.size()));
                    System.out.println(contador);
                    contador++;

                    reader.endArray();      //cerramos array de dato
                    System.out.println("cerramos array de dato");


                }
                System.out.println("Salimos del while");
                //reader.beginArray();      //cerramos array prices

                reader.endArray();
                System.out.println("cerramos array prices");
                while(reader.hasNext()){
                    System.out.println("saltamos");
                    reader.skipValue();
                }


                reader.endObject();
                System.out.println("cerramos final");

            } catch (Exception e) {
                System.out.println("Exception");
                System.out.println(e);

                return null;
            }

        }

        return prices;
    }
}
